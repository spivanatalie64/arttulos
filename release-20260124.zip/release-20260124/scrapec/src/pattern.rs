// src/pattern.rs
// ScrapeC Pattern Matching and Algebraic Data Types (Stub)

pub fn match_example(x: i64) -> &'static str {
    match x {
        0 => "zero",
        1 => "one",
        _ => "other",
    }
}
