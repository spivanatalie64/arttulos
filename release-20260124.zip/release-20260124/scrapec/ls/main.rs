// scrapec-ls: ScrapeC Language Server (Stub)
fn main() {
    println!("scrapec-ls: ScrapeC language server (stub)");
}
