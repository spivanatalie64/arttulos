# Code of Conduct

All contributors are expected to be respectful, inclusive, and constructive. Harassment or discrimination of any kind will not be tolerated.

If you experience or witness unacceptable behavior, please report it to the maintainers.
